﻿using System;

namespace _01ComparacaoString
{
    class Program
    {
        static void Main(string[] args)
        {
            string mensagem = "Reconhecer o conceito de programação estruturada, elencando as três formas de controle de fluxo do código.";

            // bool ehIgual = mensagem.Equals("Reconhecer o conceito de programação estruturada, elencando as três formas de controle de fluxo do código.");
            bool ehIgual = mensagem == "Reconhecer o conceito de programação estruturada, elencando as três formas de controle de fluxo do código.";
            Console.WriteLine(ehIgual);

            // É diferente
            ehIgual = mensagem != "Reconhecer o conceito de programação estruturada, elencando as três formas de controle de fluxo do código.";
            Console.WriteLine(ehIgual);

            bool comecaCom = mensagem.StartsWith("Reconhecer");
            Console.WriteLine(comecaCom);

            bool contemMsg = mensagem.Contains("três");
            Console.WriteLine(contemMsg);
        }
    }
}