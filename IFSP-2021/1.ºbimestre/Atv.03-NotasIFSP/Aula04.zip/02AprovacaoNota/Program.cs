﻿using System;

namespace _02AprovacaoNota
{
    class Program
    {
        static void Main(string[] arg)
        {
            // Entrar com a nota da etapa1
            Console.Write("Insira a nota da 1ª etapa: ");
            string entrada1 = Console.ReadLine();
            double etapa1 = double.Parse(entrada1);

            // Entrar com a nota da etapa2
            Console.Write("Insira a nota da 2ª etapa: ");
            string entrada2 = Console.ReadLine();
            double etapa2 = double.Parse(entrada2);
            
            // Entrar com a nota da etapa3
            Console.Write("Insira a nota da 3ª etapa: ");
            string entrada3 = Console.ReadLine();
            double etapa3 = double.Parse(entrada3);
            
            // Entrar com a nota da etapa4
            Console.Write("Insira a nota da 4ª etapa: ");
            string entrada4 = Console.ReadLine();
            double etapa4 = double.Parse(entrada4);

            // Calcular a média
            double media = (etapa1 + etapa2 + etapa3 + etapa4) / 4;

            // Imprimir se foi aprovado(a)
            string foiAprovad;
            if (media >= 6) 
                foiAprovad = "Aprovado(a)";
            else
                foiAprovad = "Reprovado(a)";
            
            Console.WriteLine("{1} com a média {0}!", media, foiAprovad);
        }
    }
}
