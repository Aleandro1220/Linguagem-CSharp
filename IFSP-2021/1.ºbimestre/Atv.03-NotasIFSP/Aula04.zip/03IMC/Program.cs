﻿using System;

namespace _03IMC
{
    class Program
    {
        static void Main(string[] args)
        {
            // Entrada do peso
            Console.Write("Entre com o seu peso em kg: ");
            string entradaPeso = Console.ReadLine();
            double peso = double.Parse(entradaPeso);

            // Entrada da altura
            Console.Write("Entre com a sua altura em metros: ");
            string entradaAltura = Console.ReadLine();
            double altura = double.Parse(entradaAltura);

            // Calcular o IMC
            double imc = peso / Math.Pow(altura, 2);

            // Exibir o resultado do IMC e classificação
            Console.WriteLine("O seu IMC é: {0:F1}", imc);

            string classificacaoIMC;
            if (imc < 18.5)
                classificacaoIMC = "peso baixo";
            else if (imc < 25)
                classificacaoIMC = "peso normal";
            else if (imc < 30)
                classificacaoIMC = "sobrepeso";
            else if (imc < 35)
                classificacaoIMC = "obesidade (grau I)";
            else if (imc < 40)
                classificacaoIMC = "obesidade severa (grau II)";
            else
                classificacaoIMC = "obesidade mórbida (grau III)";

            Console.WriteLine("A classificação do seu IMC é: {0}", classificacaoIMC);
        }
    }
}
