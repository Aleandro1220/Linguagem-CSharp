﻿using System;

namespace _01Chapeuzinho
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("A chapeuzinho vai levar doces para a vovozinha");
            Console.WriteLine("Encontra o lobo que fala para seguir pelo atalho");
            Console.Write("Você vai pelo atalho (S/N)? ");

            string escolha = Console.ReadLine();
            if (escolha == "S") {
                Console.WriteLine("Quando você chegou à casa da vovozinha o lobo a tinha comido e estava te esperando!");
            } else {
                Console.WriteLine("Você encontrou a vovozinha e entregou os doces a ela!");
            }
        }
    }
}
