﻿using System;

namespace _03JogoChave
{
    class Program
    {
        static void Main(string[] args)
        {
            bool pegouChaves = false;

            Console.WriteLine("CRÉDITOS: Caio Hamamura");
            Console.WriteLine("----------------------------");
            Console.WriteLine("---------- INICIO ----------");
            Console.WriteLine("----------------------------");

            Console.WriteLine("Você está atrasado para o trabalho, mas esqueceu onde deixou as chaves do escritório!");
            
            DescricaoSala:
            Console.ResetColor();
            Console.Write("Procure pelas chaves na sala da casa antes de ");
            
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("sair");
            
            Console.ResetColor();
            Console.WriteLine(" para o trabalho!");

            
            
            Console.Write("Na sala temos uma ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("estante");
            Console.ResetColor();
            Console.Write(" de livros, uma ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("mesa ");
            Console.ResetColor();
            Console.Write("com ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("gavetas");
            Console.ResetColor();
            Console.WriteLine(".");

            Console.WriteLine("Digite uma das palavras em magenta para procurar nesses lugares, ou sair para ir ao trabalho!");

            string escolha = Console.ReadLine();

            Console.ForegroundColor = ConsoleColor.Yellow;
            switch (escolha)
            {
                case "estante":
                case "mesa":
                    Console.WriteLine("Você não encontrou as chaves aqui!");
                    Console.WriteLine("Aperte qualquer tecla para continuar...");
                    Console.ReadKey(); // retorna a tecla pressionada (espera o usuario apertar um tecla) 
                    goto DescricaoSala;

                case "gavetas":
                    goto DescricaoGavetas;

                case "sair":
                    if (pegouChaves) 
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Você saiu para o trabalho com as chaves do escritório! Parabéns!");
                        Console.ResetColor();
                        return;
                    }
                    else 
                    {
                        Console.WriteLine("Você ainda precisa achar as chaves!");
                        goto DescricaoSala;
                    }

                default:
                    Console.WriteLine("Não entendi o que você está querendo fazer!");
                    goto DescricaoSala;
            }       

            DescricaoGavetas:     
            Console.ResetColor();
            Console.Write("A mesa possui três gavetas, gaveta ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("1");
            Console.ResetColor();
            Console.Write(", ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("2 ");
            Console.ResetColor();
            Console.Write("e ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("3");
            Console.ResetColor();
            Console.Write(". Você pode procurar em uma das três gavetas ou ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("voltar ");
            Console.ResetColor();
            Console.WriteLine("para a sala toda!");

            string gavetaEscolhida = Console.ReadLine();

            Console.ForegroundColor = ConsoleColor.Yellow;
            switch (gavetaEscolhida)
            {
                case "1":
                case "3":
                    Console.WriteLine("Você não encontrou as chaves aqui!");
                    goto DescricaoGavetas;
                case "2":
                    if (!pegouChaves)
                    {
                        Console.WriteLine("Você achou as chaves!");
                        pegouChaves = true;
                    }
                    else 
                    {
                        Console.WriteLine("Você já pegou as chaves que estavam aqui!");
                    }
                    goto DescricaoGavetas;
                case "voltar":
                    goto DescricaoSala;
                default:
                    Console.WriteLine("Não entendi o que você quer fazer!");
                    goto DescricaoGavetas;
            }
            
            
        }
    }
}
